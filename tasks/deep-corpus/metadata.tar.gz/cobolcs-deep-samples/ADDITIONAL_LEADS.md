# 今回の収集以外の追加候補

- [Rocket COBOL Fundamentals](https://github.com/RocketSoftware/cobol-fundamentals-training)：52個の`.cbl`を確認。短い業務・教育例に加え、TYPEDEF／DECLARE等の拡張がある。取得した版のトップレベルにLICENSEが見つからず、ソースにはAll Rights Reserved表示があるため、今回の配布ZIPには原文を同梱していない。単独入力としての適性は高い。
- [IBMStockTrader/cash-account-cobol](https://github.com/IBMStockTrader/cash-account-cobol)：CASH00.cblと2個の`.cpy`を確認。CICS・DB2・VSAMの現実的な組合せ。取得した版に明確なLICENSEが見つからなかったため出典案内に留めた。
- [富士通NetCOBOL 例題プログラム](https://resources.global.fujitsu/software/manual/b1wd-3697/01z000/b1wd-3697-01z0.pdf)：公式説明では製品インストール先Samplesにソースがある。公開マニュアルだけを元に製品同梱ソースを取得済みとはしない。手元のNetCOBOL Samplesがあれば、実方言の確認に追加価値がある。
- [GnuCOBOL contrib](https://github.com/OCamlPro/gnucobol-contrib)：ACAS本体に見える`samples/ACAS`は取得版ではreadme中心。今回同梱のSQL precompiler配下ACAS関連ソース3本と、完全な会計アプリ一式を混同しない。
- `eclipse-che4z/che-che4z-lsp-for-cobol`：試したmain/master/developのZIP取得先は404だった。収集済み件数へ含めていない。

検索した範囲では、公開リポジトリ上の「production-grade」「銀行システム」等の名称だけで本番稼働歴を判断していない。今回の一覧では実用ツール・業務デモ・公式業務ソース・研究データを区別した。
