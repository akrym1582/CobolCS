# 取得元と実測件数

| 取得元 | COBOL入力候補 | .at | 利用目的 |
|---|---:|---:|---|
| [uwol/proleap-cobol-parser](https://github.com/uwol/proleap-cobol-parser) | 759 | 0 | NIST適合テストと構文・前処理テスト |
| [TypeCobolTeam/TypeCobol](https://github.com/TypeCobolTeam/TypeCobol) | 911 | 0 | IBM COBOL／拡張構文／不正入力／生成期待値 |
| [cicsdev/cics-genapp](https://github.com/cicsdev/cics-genapp) | 31 | 0 | 保険契約・顧客・CICS／DB2 |
| [IBM/idz-utilities](https://github.com/IBM/idz-utilities) | 6 | 0 | Global Auto Mart業務サンプル |
| [IBM/zopeneditor-sample](https://github.com/IBM/zopeneditor-sample) | 5 | 0 | IBM COBOL・COPY・開発例 |
| [OCamlPro/gnucobol-contrib](https://github.com/OCamlPro/gnucobol-contrib) | 581 | 0 | 実用ツール・索引ファイル・画面・SQL・ソケット |
| [opensourcecobol/opensource-cobol](https://github.com/opensourcecobol/opensource-cobol) | 2 | 83 | 日本語・SJIS／UTF-8・NATIONAL・byte表現テスト |
| [opensourcecobol/opensourcecobol4j](https://github.com/opensourcecobol/opensourcecobol4j) | 416 | 157 | COBOL→Java処理系の構文・実行回帰例 |
| [opensourcecobol/Open-COBOL-ESQL](https://github.com/opensourcecobol/Open-COBOL-ESQL) | 5 | 30 | PostgreSQL埋め込みSQL・日本語Shift-JIS例 |
| [PhaseChangeSoftware/cobol-defects-suite](https://github.com/PhaseChangeSoftware/cobol-defects-suite) | 53 | 0 | OpenCBS: 開発者の不具合を再構成したケース |
| [dinodev76/GC-Examples](https://github.com/dinodev76/GC-Examples) | 6 | 0 | 索引ファイル・RDW・ファイル変換 |
| [fzn0x/core-banking-system](https://github.com/fzn0x/core-banking-system) | 4 | 0 | 小規模銀行デモ・入出金・帳票 |
| [OlegKunitsyn/gnucobol-examples](https://github.com/OlegKunitsyn/gnucobol-examples) | 5 | 0 | ライブラリ・マイクロサービス・ロギング |
| [bushidocodes/pc-pricer](https://github.com/bushidocodes/pc-pricer) | 157 | 0 | 医療費支払計算。上流で名称変更・一部修正あり |
| [CMS/ESRD-original](https://www.cms.gov/files/zip/cy-20212-esrd-main-frame-pricing-programs.zip) | 21 | 0 | 公式配布の拡張子なしCOBOL、名称変更・修正なし |

## 固定リビジョンと出典表示

### uwol/proleap-cobol-parser

- 取得元: https://github.com/uwol/proleap-cobol-parser
- SHA／版: `d1bfe75bdd6d480f70c74c6345bcc02610ac30d3`
- ライセンス表示: MIT root; NIST等の個別由来は原ヘッダー参照
- 取得ZIP SHA-256: `97fe08607ae6575de7768b38cdba7a7a5bd440f2ce7629cc7b953d0338b80474`

### TypeCobolTeam/TypeCobol

- 取得元: https://github.com/TypeCobolTeam/TypeCobol
- SHA／版: `d6c1b52f0bad3565daadb79093dd016ab8f52e3d`
- ライセンス表示: CeCILL-C root
- 取得ZIP SHA-256: `17b18c6ae07353ba72088c7afb88561327105a8b9dd8a5be2ef7208f62ddd6ee`

### cicsdev/cics-genapp

- 取得元: https://github.com/cicsdev/cics-genapp
- SHA／版: `f6f3f4b2580d31b7d8dcc31ce3e3676f4cceaaaa`
- ライセンス表示: EPL-2.0
- 取得ZIP SHA-256: `72f9d52ed834c6a6c28a2a9324305ae5c4aade3a07a405cf9eeabef8524c46ee`

### IBM/idz-utilities

- 取得元: https://github.com/IBM/idz-utilities
- SHA／版: `2bf82cd19a1e640f2f3802d6583de6dd06fd0f6a`
- ライセンス表示: Apache-2.0
- 取得ZIP SHA-256: `813fb55100406040163272ee9fb4713e7976db7124f4546ab103dc5c531735c5`

### IBM/zopeneditor-sample

- 取得元: https://github.com/IBM/zopeneditor-sample
- SHA／版: `8f9835308de6159eb54f226041d5f81a780cb8eb`
- ライセンス表示: Apache-2.0
- 取得ZIP SHA-256: `679a47214bb2b412313627717c4edff331866064f620bf78fb0140a41e4158b6`

### OCamlPro/gnucobol-contrib

- 取得元: https://github.com/OCamlPro/gnucobol-contrib
- SHA／版: `6c1980f520fe74a1c1ceccbe90e57c0c9dfed3a1`
- ライセンス表示: mixed: 各貢献物のLICENSE／ヘッダー
- 取得ZIP SHA-256: `d67947dd4ef5b7b5d55537e841970c121eee965b1e8868f06d93822f432c6219`

### opensourcecobol/opensource-cobol

- 取得元: https://github.com/opensourcecobol/opensource-cobol
- SHA／版: `b0794035c93b25ef069282ca02bb9a4d88bdf930`
- ライセンス表示: GPL／LGPL／GFDL: 個別COPYING参照
- 取得ZIP SHA-256: `eb9934c98289f35ebd27498a82dfe63f647a63e11e325e1197c2ad3687f0b3ac`

### opensourcecobol/opensourcecobol4j

- 取得元: https://github.com/opensourcecobol/opensourcecobol4j
- SHA／版: `750d4593a99554556c9074cbafeb4ca2d7e5f657`
- ライセンス表示: GPL／LGPL等: 個別COPYING参照
- 取得ZIP SHA-256: `748f8f781bffb70b22ed4d73c4e2bb53b09140fa4a9f54fd8489483f8a73b25c`

### opensourcecobol/Open-COBOL-ESQL

- 取得元: https://github.com/opensourcecobol/Open-COBOL-ESQL
- SHA／版: `14591d82b6423ed76540ced70f1d4752d31882f3`
- ライセンス表示: GPL／LGPL／GFDL: 個別COPYING参照
- 取得ZIP SHA-256: `831e1238f98b86b7133ae285c632937cc0e972de5f3e8a29de72c91aef138d8e`

### PhaseChangeSoftware/cobol-defects-suite

- 取得元: https://github.com/PhaseChangeSoftware/cobol-defects-suite
- SHA／版: `a7a10bb0330c021c973792d1fd05275475bbcce1`
- ライセンス表示: MIT
- 取得ZIP SHA-256: `d90485b6788dadd1ca78aef706db8654fd80b3bbba10a66d397ebc98eb2cd3e7`

### dinodev76/GC-Examples

- 取得元: https://github.com/dinodev76/GC-Examples
- SHA／版: `2b8546c7c0a6297b6100a4513d2bdefd57f58928`
- ライセンス表示: MIT
- 取得ZIP SHA-256: `8f96f380b800c1e716660063fee8c913267b17959ac0eaf26949533fb5b0d393`

### fzn0x/core-banking-system

- 取得元: https://github.com/fzn0x/core-banking-system
- SHA／版: `770860d4a11f1d203b0369456d867108097a550f`
- ライセンス表示: MIT
- 取得ZIP SHA-256: `31a2b359865385e8f5989926d96b5fd4b4abb0e147885b4cd8acf0f4a683305e`

### OlegKunitsyn/gnucobol-examples

- 取得元: https://github.com/OlegKunitsyn/gnucobol-examples
- SHA／版: `c861c1b2929a35c952e3f5b3d0d879a9061185f1`
- ライセンス表示: GPL-3.0 root
- 取得ZIP SHA-256: `b697ddcb6e183f98b6cabcf07530d32a9b70cb72e165e92615e83e7673153891`

### bushidocodes/pc-pricer

- 取得元: https://github.com/bushidocodes/pc-pricer
- SHA／版: `e3b17304c7b96d48b8adc62602d9618490366435`
- ライセンス表示: CC0 compilation; CMS由来、詳細は上流LICENSE
- 取得ZIP SHA-256: `910206ad8d06c71357cb2863e6c73838ac741fcf7120a991ad2a5efa3d36ca3b`

### CMS/ESRD-original

- 取得元: https://www.cms.gov/files/zip/cy-20212-esrd-main-frame-pricing-programs.zip
- SHA／版: `release 2021.2`
- ライセンス表示: CMS公式配布
- 取得ZIP SHA-256: `eafa667da31e8dfee4595f77bbb07fde67cb6469cc10240d84a9d43296334213`

## X-COBOL v2

- 配布元: https://zenodo.org/records/14269462
- DOI: https://doi.org/10.5281/zenodo.14269462
- 5,195ファイル、配布説明では168リポジトリ。ZIP中のowner@repo directoryを保持。
- 配布レコードの帰属: Sridhar Chimalakonda。元コードの個別権利表示を置き換えない。
- 公開MD5: `cbd974caed72b0836777dc2305928ed3`（取得bytesと一致）。
- 元のZIPを変更せず`X-COBOL-v2.zip`というダウンロード名で提供。
- 配布レコードと付属統計の原文をmetadata以下へ保存。
